import traceback
import json

from pymongo import MongoClient
from pymongo.errors import WriteConcernError, WriteError


class crud:


    def __init__(self, username: str, password: str):


#Create Method with Mongo Access
        self.client = MongoClient('mongodb://%s:%s@localhost:49997/AAC' % (username, password))
        self.collection = self.client['AAC']["animals"]

    def create(self, doc_to_insert: dict) -> bool:


        inserted = False
        if doc_to_insert is not None:
            self.collection.insert_one(doc_to_insert)
            inserted = True

        else:
            raise Exception("Nothing to save, data parameter empty")

        return inserted
#Read Method
    def findDocs(self, search_criteria: dict):


        if search_criteria is not None:
            results = self.collection.find(search_criteria)
            return results

        else:
            raise Exception("Something went wrong. Check the search criteria and try again")

#Update Method
    def update(self, look_up_values: dict, new_values: dict):


        result = None
        try:


            if look_up_values is not None and new_values is not None:

                result = self.collection.update_one(look_up_values, {"$set": new_values})

                # returns true if update was successful
                if result.modified_count != 0:
                    print("Successfully updated document")

                else:
                    print("Failed to update document")

                json_object = json.dumps(result.raw_result, indent=4)
                return json_object

            else:
                raise Exception("look up values or update values were not specified")

        # Returns error if error found
        except WriteConcernError as wce:
            print("A WriteConcernError occurred")
            return wce
        except WriteError as we:
            print("A WriteError occurred")
            return we
        except:
            print("An error occurred when trying to update the document")
            traceback.print_exc()

#Delete Method
    def delete(self, doc_to_delete: dict):


        try:

            if doc_to_delete is not None:

                result = self.collection.delete_one(doc_to_delete)


                if result.deleted_count > 0:
                    print("Deletion successful")
                else:
                    print("Failed to delete document")

                json_object = json.dumps(result.raw_result, indent=4)
                return json_object

            else:
                raise Exception("doc_to_delete variable was null")

        # Returns error if error found during deletion
        except WriteConcernError as wce:
            print("A WriteConcernError occurred")
            return wce
        except WriteError as we:
            print("A WriteError occurred")
            return we
        except:
            print("An error ocurred when trying to delete the document")
            traceback.print_exc()